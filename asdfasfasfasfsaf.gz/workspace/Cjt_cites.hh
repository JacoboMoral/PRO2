#ifndef Cjt_cites_hh
#define Cjt_cites_hh


/** @file Cjt_cites.hh
    @brief Especificació de la classe Cjt_cites
*/

#ifndef NO_DIAGRAM
#include <map>
#endif
#include "Cita.hh"
using namespace std;
/** @class Cjt_cites
    @brief Representa el conjunt de cites. 
    Es guardaran totes les cites.
 */

class Cjt_cites
{
  
private:
	map<string,Cita> mapcites;
	map<string,int> maxnum_inicials;
  
  
public:

    //constructores
  
   /** @brief Creadora per defecte. S'executa automàticament en declarar un Cjt de textos.
    
      \pre <em>cert</em>
      \post El resultat és un conjunt de cites sense inicialitzar
  */  
  Cjt_cites();

  
    //modificadores
  
    /** @brief Afegeix una cita 
   
        \pre El paràmetre implícit no conté cap cita amb el mateix contingut 
        \post S'ha afegit la cita cta al paràmetre implícit 
    */
    void afegir_cita(Cita &cta);

  
  
    /** @brief Mostra la informació d'una cita 
   
        \pre <em>cert</em>
        \post Mostra l'autor, el títol, el número de la frase inicial i el de la frase final, a més del contingut de
        la frase o frases que componen la cita la referència de la qual està al paràmetre implícit 
    */
    void informacio_cita(string &ref);
  
  

    /** @brief Mostra totes les cites del conjunt de cites.
   
        \pre <em>cert</em>
        \post Mostra totes les cites (referència, contingut de les frases, i títol del text d'on provenen, 
        de l'autor "autor"
    */
    void cites_autor(string autor);
      
     
     
    /** @brief Elimina la cita amb la referència esmentada.
   
        \pre <em>cert</em>
        \post Esborra de la llista de cites la cita la referència de la qual es "ref"
    */
    void eliminar_cita(string &ref);


    
    // destructores
  
    /** @brief Destructora per defecte.
   
        \pre <em>cert</em>
        \post Esborra els objectes automàticament en sortir d'un àmbit de visibilitat
    */
    ~Cjt_cites();

};


#endif