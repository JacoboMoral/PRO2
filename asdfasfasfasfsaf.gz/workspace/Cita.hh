#ifndef Cita_hh
#define Cita_hh


/** @file Cita.hh
    @brief Especificació de la classe Cita
*/


#ifndef NO_DIAGRAM
#include <string>
#include <utility>  //pair
#include <vector>
#endif
using namespace std;

/** @class Cita
    @brief Representa una cita 

 */

class Cita
{
private:
	pair <int,int> interval_frases;
	string inicials;
	string autor;
	string titol;
	vector<string> contingut_cita;


public:

    //constructores
    
    /** @brief Creadora per defecte. S'executa automaticament en declarar una cita.
     
        \pre <em>cert</em>
        \post El resultat és una cita sense inicialitzar
    */  
    Cita();
    
    
    /** @brief Creadora inicialitzada
     
        \pre <em>cert</em>
        \post El resultat és una cita inicialitzada amb els paràmetres passats.
    */
    Cita(string autor, string contingut, string titol);

    
    //Consultores

    /** @brief Consulta l'autor de la cita.
     
        \pre Hi ha un autor en el paràmetre implícit
        \post El resultat és l'autor del paràmetre implícit
    */
    string consultar_autor();
    
    
    /** @brief Consulta la referència (ref)
      
        \pre Hi ha una referència en el paràmetre implícit
    	\post El resultat és la referencia del paràmetre implícit
    */
    string consultar_ref();

    
    /** @brief Consulta el títol de la cita.
      
        \pre Hi ha un títol en el paràmetre implícit
        \post El resultat é el títol del paràmetre implícit
    */
    string consultar_titol();

    /** @brief Consulta el número de frase de
      
        \pre Hi ha un número de frase en el paràmetre implícit
        \post El resultat és el interval de les frases on es troba el paràmetre implícit
    */
    pair<int,int> consultar_numero_frase();

    
    // destructora
    
    /** @brief Destructora per defecte.
  
        \pre cert
        \post Esborra els objectes automàticament en sortir d'un àmbit de visibilitat
    */ 
    ~Cita();
    
};

#endif