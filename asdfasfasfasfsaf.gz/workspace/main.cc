/**
 * @mainpage Pràctica de Pro2:  Gestió de llibres i cites.
 
En aquest programa es gestiona un conjunt de textos amb autor i títol, llibres, i també cites tretes d'aquests llibres. S'utilitzen les classes <em>Cjt_textos</em>, 
<em>Text</em>, <em>Cjt_cites</em> y <em>Cita</em>.

*/

/** @file main.cc
    @brief Programa principal de la pràctica de Pro2.
*/

#ifndef NO_DIAGRAM
#include <sstream>
#include <iostream>
#endif
#include "Cjt_textos.hh"     
#include "Text.hh"               //Redundant, serveix pel diagrama de classes
#include "Cjt_cites.hh"
#include "Cita.hh"

using namespace std;

int main(){
  string linia, op, seg, sublinia;
  getline(cin,linia);
  while (linia != "sortir"){
    istringstream iss(linia);
    iss >> op;
    cout << linia << endl;
    if (op == "afegir"){
      iss >> seg;
      if (seg == "text"){
        ws(iss);
        getline(iss,sublinia);

      }
      else if (seg == "cita"){
      }
    }
    else if(op == "triar"){
    }
    else if(op == "eliminar"){
      iss >> seg;
      if(seg == "text"){
      }
      else if(seg == "cita"){
      }
    }
    else if(op == "substitueix"){
    }
    else if(op == "textos"){
    }
    else if(op == "tots"){
      iss >> seg;
      if(seg == "autors"){
      }
      else if (seg == "textos"){
      }
    }
    else if(op == "info"){
      iss >> seg;
      if (seg == "?"){
      }
      else if (seg == "cita"){
      }
    }
    else if(op == "autor"){
    }
    else if(op == "contingut"){
    }
    else if(op == "frases"){
    }
    else if(op == "nombre"){
      iss >> seg;
      iss >> seg;
      if (seg == "frases"){
      }
      else if(seg == "paraules"){
      }
    }
    else if(op == "taula"){
    }
    else if(op == "cites"){
      iss >> seg;
      if (seg == "autor"){
      }
      else if (seg == "?"){
      }
    }
    else if(op == "totes"){
    }
    else cout << "error" << endl;
    
    do{
    	 getline(cin,linia);
    	}while (linia.empty());
  }
}
