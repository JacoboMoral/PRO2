#include "Cjt_textos.hh"

class Cjt_textos{
  
  
private:

    void llegir_autor(){
	    getline(cin,autor_triat);
	    autor_triat.erase(0,7);
        autor_triat.erase(autor_triat.size()-1,1);
    }
    void llegir_titol(){
        getline(cin,titol_triat);
        titol_triat.erase(0,13);
        titol_triat.erase(titol_triat.size()-1,1);
    }
    
    void llegir_text(Text txt){
        txt.llegir_text();
    }

public:
    void Cjt_textos::afegir_text(){
        llegir_titol();
        llegir_autor();
        Text txt;
        llegir_text(txt);
        titol_i_contingut.insert(titol_triat,txt);
        for (int i = 0; i < text)
        text.insert(autor_triat,titol_i_contingut);
        
        
        
        

        
    }
   
   