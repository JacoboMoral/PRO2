#include <vector>
#include<iostream>
#include<sstream>
#include<string>
using namespace std;

void Text::substitueix(string& frase, string buscar, string rempl) {
	int size = buscar.size();
	int pos = frase.find(buscar);
	while(pos != -1){
		    char c = frase[pos + size];
		    if ((c == ' ') or (c == '.') or (c == '!') or (c == '?') or (c == ';')){
		    	frase.replace(pos, buscar.size(), rempl);
		    }
		    pos = frase.find(buscar, pos + rempl.size());
	}
}



void Text::llegir_text(){
    string n;
    cin >> n;
    while(n != "****"){
        string frase;
        while(n[n.size()-1] != '.' or n[n.size()-1] != '?' or n[n.size()-1] != '!'){
            frase = frase + " " + n;
            if n[n.size()-1] != '.' or n[n.size()-1] != '?' or n[n.size()-1] != '!'){
                n.erase(n.size()-1,1);
                taulafreq.insert(n);
            }
            else taulafreq.insert(n);
            cin >> n;
        }
        contingut.push_back(frase);
    }
}


