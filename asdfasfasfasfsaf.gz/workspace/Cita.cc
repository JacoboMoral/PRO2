    Cita(string autor, string contingut, identificacio() ,string titol);
    this->titol = titol;
    this->contingut = contingut;
    this-> autor = autor;