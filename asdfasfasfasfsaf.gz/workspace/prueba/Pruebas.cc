#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

int main(){
	vector <string> contingut;
	string frase,op;
	string punto = ".";
	getline(cin,frase);
	int size = frase.size();
	istringstream iss(frase);
	int pos = frase.find(punto);
	size -= pos;
	int i = 0;
	while (pos > 0){
		iss >> op;
		contingut[i] += op + " ";
		pos -= op.size();
		--pos;
	}
	while (size > 1){
		iss >> op;
		contingut[1] += op + " ";
		--size;
		size -= op.size();
	}
	cout << contingut[0] << endl;
	cout << contingut[1] << endl;
}









