#include<iostream>
using namespace std;
#include<string>



int main(){
    int n = 23425;
    pair <string,int> id;
    string s = "Jacobo Moral";
    id.first.push_back(s[0]);
    for (int i = 1; i < s.size(); ++i){
        if (s[i] == ' ') id.first.push_back(s[i+1]);
    }
    id.second = n;
    cout << id.first;
    cout << id.second << endl;
}


