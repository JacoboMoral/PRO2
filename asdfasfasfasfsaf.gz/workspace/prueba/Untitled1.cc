#include<iostream>
#include<vector>
using namespace std;
#include<string>

int girar (int n){
    int resultado = 0;
    while (n > 0){
        resultado = resultado*10 + n%10;
        n /= 10;
    }
    return resultado;
}

int main(){
    string s = "Jacobo Moral";
    int i = 1;
    vector <char> ref;
    ref.push_back(s[0]);
    while (i < s.size()){
        if (s[i] == ' ') ref.push_back(s[i+1]);
        ++i;
    }
    int d = 12;
    int k  = girar(d);
    while(k > 0){
        ref.push_back('0' + k%10);
        k = k/10;
    }
    for (int i = 0; i < ref.size(); ++i){
       cout << ref[i];
    }
    
}
