/** @file Cjt_cites.cc
    @brief Codi de la classe Cjt_cites
*/

#include "Cjt_cites.hh"
using namespace std;


Cjt_cites::Cjt_cites(){
}


Cjt_cites::~Cjt_cites(){
}


void Cjt_cites::afegir_cita(Cita &cta){
 	string ref = cta.consultar_inicials();
 	map<string,int>::iterator it = maxnum_inicials.find(ref);
 	if(maxnum_inicials.empty()) {
 	    maxnum_inicials.insert(make_pair(ref,1));
 	    ref += to_string(1);
 	}
 	
 	

 	if (mapcites.empty()) mapcites.insert(make_pair(ref,cta));
 	else {
 	    bool repetida = 0;
 	    map<string,Cita>::iterator itr;
 	    for (itr = mapcites.begin(); itr != mapcites.end(); ++itr){
 	        if ((itr->second.consultar_contingut_cita()) == (cta.consultar_contingut_cita()) and
 	        (itr->second.consultar_autor()) == (cta.consultar_autor()) and 
 	        (itr->second.consultar_titol()) == (cta.consultar_titol())) repetida = 1;
 	    }
 	    if (not repetida){
 			if (it != maxnum_inicials.end()){
 				it->second += 1;
 		 		ref += to_string(it->second);
 		 		
 			}
 			else {
 	    		maxnum_inicials.insert(make_pair(ref,1));
 	    		ref += to_string(1);
 			}
 			mapcites.insert(make_pair(ref,cta));
 	    }
 	    else cout << "error" << endl;
 	}
}


void Cjt_cites::informacio_cita(string &ref){
	ref.erase(0,1);
    ref.erase(ref.size()-1,1);
	map <string,Cita>::iterator it = mapcites.find(ref);
	if (it != mapcites.end()){
    	cout << it->second.consultar_autor() << ' ' << '"' << it->second.consultar_titol() << '"' << endl;
    	int ini = it->second.consultar_frase_ini();
    	cout << ini+1 << '-' << it->second.consultar_nombre_frases_cita() + ini << endl;
    	it->second.escriure_contingut_cita();
	}
	else cout << "error" << endl;
}


void Cjt_cites::cites_autor(string &autor){
	autor.erase(0,13);
    autor.erase(autor.size()-3,3);
	map <string,Cita>::iterator it;
	for (it = mapcites.begin(); it != mapcites.end(); ++it){
		if ((it ->second.consultar_autor()) == autor){
			cout << it->first << endl;
			it->second.escriure_contingut_cita();
			cout << '"' << it->second.consultar_titol() << '"' << endl;
		}
	}
}


void Cjt_cites::eliminar_cita(string &ref){
	ref.erase(0,1);
    ref.erase(ref.size()-1,1);
    map<string,Cita>::iterator it;
   	it = mapcites.find(ref);
   	if (it != mapcites.end()){
   		mapcites.erase(it);
   	}
   	else cout << "error" << endl;
}


void Cjt_cites::mostrar_totes_cites(){
	map <string,Cita>::iterator it;
	for (it = mapcites.begin(); it != mapcites.end(); ++it){
		cout << it->first << endl;
		it->second.escriure_contingut_cita();
		cout << it->second.consultar_autor() << ' ' << '"' << it->second.consultar_titol() << '"' << endl;
	}
}


void Cjt_cites::cites_text_triat(string &autor, string &titol, bool tipo){
	map <string,Cita>::iterator it;
	for (it = mapcites.begin(); it != mapcites.end(); ++it){
		if ((it ->second.consultar_autor() == autor) and (it->second.consultar_titol() == titol)){
			cout << it->first << endl;
			it->second.escriure_contingut_cita();
			if (tipo == 1){
				cout << it->second.consultar_autor() << ' ' << '"' << it->second.consultar_titol() << '"' << endl;
			}
		}
	}
}