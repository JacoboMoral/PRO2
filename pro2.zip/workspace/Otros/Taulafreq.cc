#include<list>
#include<iostream>
#include<sstream>
#include<vector>
#include<utility>
using namespace std;

int main(){
	vector<string> contingut;
	list<pair<string,int> >taulafreq;
	pair<string,int> paraula;
	string n, op;
    cin >> n;
    bool next = 0;
    bool first = 1;
    int i = 0;
    while(n != "****"){
        if (first){
            contingut.push_back(n);
            first = 0;
        }
        else if (next){
            contingut.push_back(n);
            next = 0;
        }
        else if ((n[n.size()-1] == '.') or (n[n.size()-1] == '?') or (n[n.size()-1] == '!')){
            next = 1;
            contingut[i] += " " + n;
            ++i;
        }
        else {
            contingut[i] += " " + n;
        }
        cin >> n;
    }
    for(int i = 0; i < contingut.size(); ++i){
    	istringstream iss(contingut[i]);
    	while(iss >> op){
    		list<pair<string,int> >::iterator it = taulafreq.begin();
    		if(op[op.size()-1] == ',' or op[op.size()-1] == '.' or op[op.size()-1] == '?'
			or op[op.size()-1] == ';' or op[op.size()-1] == ':' or op[op.size()-1] == '!'){
				op.erase(op.size()-1,1);
			}
    		if (taulafreq.empty()){
    			paraula = make_pair(op , 1);
    			taulafreq.insert(it,paraula);
    		}
    		else{
    			bool trobat = false;
    			while(not trobat and it != taulafreq.end()){
    				if(it->first == op){
    					trobat = true;
					}
					else ++it;
    			}
    			if(trobat) it->second = it->second + 1;
				else{
					paraula = make_pair(op,1);
					taulafreq.insert(it,paraula);
					}
				}
			}
    	
		}
	for(list<pair<string,int> >::iterator it = taulafreq.begin();it != taulafreq.end(); ++it){
		cout << it->first << " " << it->second << endl;
	}
}

/*
de 7
el 4
en 4
que 4
la 3
construcciones 3
y 2
se 2
Los 2
una 2
zona 2
Estas 2
Nazca 2
Puquios 2
espiral 2
desertica 2
al 1
200 1
600 1
del 1
esa 1
fue 1
los 1
por 1
red 1
son 1
sur 1
Peru 1
agua 1
anos 1
eran 1
para 1
entre 1
forma 1
hasta 1
hogar 1
mismo 1
claves 1
fueron 1
hunden 1
nombre 1
pueblo 1
tierra 1
viento 1
canales 1
cultura 1
especie 1
pudiera 1
sistema 1
conducia 1
distribuir 1
sobrevivir 1
distribuyen 1
ventilacion 1
sofisticadas 1
subterraneos 1
*/