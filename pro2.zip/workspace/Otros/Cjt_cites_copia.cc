#include "Cjt_cites.hh"
using namespace std;



Cjt_cites::Cjt_cites(){}

Cjt_cites::~Cjt_cites(){}


void Cjt_cites::afegir_cita(Cita &cta){
 	string s = cta.consultar_inicials();
 	if(maxnum_inicials.empty()){
 		maxnum_inicials.insert(make_pair(s,1));
 		string k = to_string(1);
 		s = s+k;
 		map <string,Cita> ref_cita;
 		ref_cita.insert(make_pair(s,cta));
 		 mapcites.insert(make_pair(cta.consultar_autor(),ref_cita));
 	}
 	else{
 		map<string,int>::iterator it = maxnum_inicials.find(s);
 		if (it != maxnum_inicials.end()){
 			it->second = it->second +  1;
 		}
 		else{
 			maxnum_inicials.insert(make_pair(s,1));
 		}
 		map<string,map <string,Cita > >::iterator it1;
 		it1 = mapcites.find(cta.consultar_autor());
 		if (it1 != mapcites.end()){
 			map<string,int>::iterator it = maxnum_inicials.find(s);
 			string k = to_string(it->second);
 			s = s + k;
 			map <string,Cita> t_i_c = it1 -> second;
    		map <string,Cita>::iterator it3 = t_i_c.begin();
    		t_i_c.insert(make_pair(s,cta));
     		mapcites.erase(cta.consultar_autor());
       		mapcites.insert(make_pair(cta.consultar_autor(),t_i_c));
 		}
 		else{
 			it = maxnum_inicials.find(s);
 			int t = it->second;
 			string m = to_string(t);
 			s = s+m;
 			map <string,Cita> t_i_c;
 			t_i_c.insert(make_pair(s,cta));
 			mapcites.insert(make_pair(cta.consultar_autor(),t_i_c));
 		} 
 	}
}


void Cjt_cites::info(string &autor, string &titol){
	map<string,map <string,Cita> >::iterator it;
	it = mapcites.find(autor);
	Cita cta;
	if (it != mapcites.end()){
		map <string,Cita> ref_cita = it->second;
		for(map <string,Cita>::iterator it2 = ref_cita.begin(); it2 != ref_cita.end(); ++it2){
			cta = it2->second;
			if (cta.consultar_titol() == titol){
				cout << it2->first << endl;
				cta.escriure_contingut_cita();
			}
		}
	}
}

void Cjt_cites::informacio_cita(string &ref){
	ref.erase(0,1);
    ref.erase(ref.size()-1,1);
    map<string,map <string,Cita >>::iterator it;
    map <string,Cita>::iterator it2;
    Cita cta;
    for (it = mapcites.begin(); it != mapcites.end(); ++it){
    	for (it2 = it->second.begin(); it2 != it->second.end(); ++it2){
    		if (it2 -> first == ref) cta = it2 -> second;
    	}
    }
    cout << cta.consultar_autor() << ' ' << '"' << cta.consultar_titol() << '"' << endl;
    int ini = cta.consultar_frase_ini();
    cout << ini << '-' << cta.consultar_nombre_frases_cita() + ini - 1 << endl;
    cta.escriure_contingut_cita();
}

void Cjt_cites::cites_autor(string autor){
	map<string,map <string,Cita >>::iterator it = mapcites.find(autor);
	if ( it != mapcites.end()){
	map<string,Cita>::iterator it2;
	Cita cta;
	map<string,Cita > muestra = it ->second;
	it2 = muestra.begin();
	for (it2 = muestra.begin(); it2 != muestra.end(); ++it2){
		cta = it2->second;
		cout << it2 -> first << endl;
		cta.escriure_contingut_cita();
		}
	}
}

void Cjt_cites::eliminar_cita(string &ref){
	ref.erase(0,1);
    ref.erase(ref.size()-1,1);
    map<string,map <string,Cita >>::iterator it;
    map <string,Cita>::iterator it2;
    bool borrado = 0;
    it = mapcites.begin();
    while ((not borrado) and it != mapcites.end()){
    	it2 = it->second.begin();
    	while ((not borrado) and it2 != it->second.end()){
    		if (it2 -> first == ref){
    			if (it->second.size() == 1) it = mapcites.erase(it);
    			else it2 = it->second.erase(it2);
    			borrado = 1;
    		}
    		if (not borrado) ++it2;
    	}
    	if (not borrado) ++it;
    }
}
//lowerbound


//para la funcion de mostrar todas las citas ordenadas por referencia, he pensado (es muy muy ineficiente, pero bueno...) recorrer todo el map entero(y tambien map dentro del map) tantas veces como
//referencias existan. Cogemos el vector maxnum_inicials y buscamos la cita de la primera referencia. Si por ejemplo la primera referencia es AH y su numero maximo es 3, entonces
//buscamos la cita de AH1, luego de AH2 y luego de AH3. Luego la siguiente posicion de maxnum_inicials, etc.


void Cjt_cites::mostrar_totes_cites(){
	map<string,map <string,Cita > >::iterator it;
	map<string,Cita>::iterator it2;
	map<string,int>::iterator it3;
	string ref;
	string n;
	for (it3 = maxnum_inicials.begin(); it3 != maxnum_inicials.end(); ++it3){
		ref = it3->first;
		for (int i = 1; i <= it3->second; ++i){
			n = to_string(i);
			ref+=n;
			for (it = mapcites.begin(); it != mapcites.end(); ++it){
				for (it2 = it->second.begin(); it2 != it->second.end(); ++it2){
					if (it2->first == ref){
						string escriure;
						cout << it2->first << endl;
						it2->second.escriure_contingut_cita();
						cout << it2->second.consultar_autor() << ' ' << '"' << it2->second.consultar_titol() << '"' << endl;
					} 
				}
			}
			ref.erase(ref.size()-1,1);
		}
	}
}




void Cjt_cites::cites_text_triat(string &autor, string &titol){
	map<string,map <string,Cita> >::iterator it;
	it = mapcites.find(autor);
	map<string,Cita>::iterator it2;
	for (it2 = it->second.begin(); it2 != it->second.end(); ++it2){
		if (it2->second.consultar_titol() == titol){
			cout << it2->first << endl;
			it2->second.escriure_contingut_cita();
			cout << it2->second.consultar_autor() << ' ' << '"' << it2->second.consultar_titol() << '"' << endl;
		}
	}
}


/*
void Cjt_cites::mostrar_totes_cites(){
	map<string,map <string,Cita > >::iterator it;
	map<string,Cita>::iterator it2;
	map<string,int>::iterator it3;
	for (it = mapcites.begin(); it != mapcites.end(); ++it){
		cout << mapcites.size() << endl;
		for (it2 = it->second.begin(); it2 != it->second.end(); ++it2){
			cout << it->second.size() << endl;
			cout << "hola" << endl;
			it2->second.escriure_contingut_cita();
			cout << it2->second.consultar_autor() << ' ' << '"' << it2->second.consultar_titol() << '"' << endl;
		}
	}
}

*/


