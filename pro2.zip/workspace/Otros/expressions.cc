#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;


void rec(string enunciat, string s){
	string op;
	if ((enunciat[0] == '(') or (enunciat[0] == '{')){
		enunciat.erase(enunciat.begin());
		return rec(enunciat, s);
	}
//	else if (enunciat[0] == '&'){
//	else if (enunciat[0] == '|'){
	else{
		istringstream iss(enunciat);
		iss >> op;
		if ((op[op.size()-1] == '}') or (op[op.size()-1] == ')')){
			op.erase(op.end())
		}
		int pos;
		pos = s.find(op);
        if (pos != -1){
        }

	}
}




vector<bool> cerca (const vector<string> &v){
	string enunciat = "({casa} | {aigua})";
	vector<bool> vec(v.size());
	for (int i = 0; i < v.size(); ++i){
		rec(enunciat, v[i]);
	}
	return vec;
}



int main(){
	vector<string> v(4);
	v[0] = "La casa bonita es esta.";
	v[1] = "Este es mi ordenador.";
	v[2] = "Aquel es el lapiz.";
	v[3] = "Quiero un bocadillo.";
	cerca(v);
	
}