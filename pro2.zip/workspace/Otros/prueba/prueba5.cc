#include<iostream>
#include<vector>
#include<map>
using namespace std;

int main(){
    string n;
    vector<string> contingut;
    cin >> n;
    while(n != "****"){
        string frase;
        while(n[n.size()-1] != '.' and n[n.size()-1] != '?' and n[n.size()-1] != '!'){
            frase = frase + " " + n;
            cin >> n;
        }
        frase = frase + " " + n;
        contingut.push_back(frase);
        cin >> n;
    }
   	for(int i = 0 ; i < contingut.size(); ++i){
   		cout << i+1 << ' ' << contingut[i] << endl;
	}
}
