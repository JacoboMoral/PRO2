#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;





int main(){
	string titol;
	getline(cin,titol);
 	titol.erase(0,7);
 	titol.erase(titol.size()-1,1);
 	cout << titol << endl;
}







