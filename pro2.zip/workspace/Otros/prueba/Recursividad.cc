#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;


int search(const string palabra,const string palabras){
    string op;
    vector<string> v;
    istringstream iss(palabras);
    while (iss >> op){
    	if ((op[op.size()-1] == ':') or (op[op.size()-1] == '.') or (op[op.size()-1] == ',') or (op[op.size()-1] == '?') or (op[op.size()-1] == '!') or (op[op.size()-1] == ';')){
                op.erase(op.size()-1,1);
                if (op == palabra) return j;
                
            }
            else {
                if (op == palabra) return j;
            }
    }
    for (int i = 0; i < v.size(); ++i){
        if (v[i] == palabra) return j;
    }
    return -1;
	}
	

int recursivitat(const string& e, int& index,const string& m){
	if(e[index] == '{'){
		string s;
		while(index < e.size()  and e[index] != '&' and
		e[index] != '|'  and e[index] != '}'  and e[index] != ' '){
			s.push_back(e[index]);
			++index;
		}
		return search(s,m);
	}
	
	else{
		++index;
		int a1 = recursivitat(e,index,m);
		char op = e[index];
		++index;
		int a2 = recursivitat(e,index,m);
		++index;
		if (op  == '&' or op == ' '){
			if(a1 == a2) return a1;
		}
		else{
			if (a1  != -1 ) return a2; 
	}
}

int main(){
	string linia , linia2;
	getline(cin,linia);
	getline(cin,linia2);
	int k  = 0;
	cout << recursivitat(linia,k,linia2);
	
}