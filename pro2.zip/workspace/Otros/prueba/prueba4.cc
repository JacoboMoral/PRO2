#include <string>
#include <iostream>
#include <map>
using namespace std;

int main(){
	map <string,string> titol_i_contingut;
	map <string, map <string,string>> text;
	map<string,map<string,string>>::iterator it;
	map <string,string>::iterator it2;


	titol_i_contingut.insert(make_pair("titulo de alberto","este es el primer texto de alberto garzon"));
	text.insert(make_pair("alberto garzon",titol_i_contingut));
	
	
	titol_i_contingut.insert(make_pair("titulo 2 de alberto","este es el segundo texto de alberto garzon"));
	text.erase("alberto garzon");
	text.insert(make_pair("alberto garzon",titol_i_contingut));
	
	
	titol_i_contingut.insert(make_pair("titulo de isabel","este es el primer texto de isabel allende"));
	text.insert(make_pair("isabel allende",titol_i_contingut));
	
	
	
	
	
	
	for (it = text.begin(); it != text.end(); ++it){
		if (it->first == "isabel allende") cout << "hola" << endl;
		else cout << "adios" << endl;
	}
	cout << text.size() << endl;
	
	it = text.find("alberto garzon");
	int k = it->second.size();
	cout << k << endl;
    it->second.erase("titulo 2 de alberto");
    k = it->second.size();
    cout << k << endl;
    cout << text.size() << endl;
	
	cout << endl << endl;
	cout << text["alberto garzon"]["titulo de alberto"] << endl;
	cout << text["alberto garzon"]["titulo 2 de alberto"] << endl;
	cout << text["isabel allende"]["titulo de isabel"] << endl;
}














/*

#include <string>
#include <iostream>
#include <map>
using namespace std;




    	


int main(){
	map <string,string> titol_i_contingut;
	map <string, map <string,string>> text;
	map<string,map<string,string>>::iterator it_triat_autor;
	map<string,string>::iterator it_triat_titol_i_contingut;


	titol_i_contingut.insert(make_pair("titulo de alberto","este es el primer texto de alberto garzon"));
	text.insert(make_pair("alberto garzon",titol_i_contingut));
	
	
	titol_i_contingut.insert(make_pair("titulo 2 de alberto","este es el segundo texto de alberto garzon"));
	text.erase("alberto garzon");
	text.insert(make_pair("alberto garzon",titol_i_contingut));
	
	
	titol_i_contingut.insert(make_pair("titulo de isabel","este es el primer texto de isabel allende"));
	text.insert(make_pair("isabel allende",titol_i_contingut));
	
	
	
	
	it_triat_titol_i_contingut = titol_i_contingut.begin();

	
	
	if(titol_i_contingut.size() == 1){
    		text.erase(it_triat_autor->first);
    	}
    	else {
    		titol_i_contingut.erase(it_triat_titol_i_contingut->first);
    }

	

	cout << text["alberto garzon"]["titulo de alberto"] << endl;
	cout << text["alberto garzon"]["titulo 2 de alberto"] << endl;
	cout << text["isabel allende"]["titulo de isabel"] << endl;
}
*/