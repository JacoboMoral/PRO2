#include<iostream>
#include<vector>
using namespace std;
#include<string>

int main(){
    string niggi;
   	cin  >> niggi;
	int value = atoi(niggi.c_str()); 
    cout << value ;
}


/* int main(){
    string s, k;
    vector<string> frase;
    getline(cin,s);
    frase.push_back(s);
    
    for(int i = 0; i < frase.size(); ++i){
	stringstream iss(frase[i]);
	while(iss >> k){
	cout << k << endl;
	}
    }
}
*/
    