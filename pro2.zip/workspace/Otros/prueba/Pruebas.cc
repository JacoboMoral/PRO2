#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;
  
int main(){
	string autor_cita;
	getline(cin,autor_cita);
    istringstream iss (autor_cita);
    string op;
    string inicials_cita;
	while (iss >> op){
		inicials_cita += op[0];
	}
	cout << inicials_cita;
}