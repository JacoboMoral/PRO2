#include <iostream>
#include <string>
#include <vector>
#include <sstream>
using namespace std;

int main(){
	string line, op;
	line = "({(Hola que tal estas?";
	istringstream iss(line);
	line.erase(line.end()-1);
	cout << line << endl;

	
	
	
}