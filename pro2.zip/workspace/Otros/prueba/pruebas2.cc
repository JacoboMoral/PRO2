#include <iostream>
#include <string>
#include <sstream>
#include <vector>
using namespace std;

void treure_cometes(string& s){
	int  k = s.size();
	s.erase(0);
	s.erase(k);
}




int main(){
	string titol;
	getline(cin,titol);
 	cout << titol << endl;
 	treure_cometes(titol);
 	cout << titol << endl;
}





























