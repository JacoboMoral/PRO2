#include <iostream>
#include <vector>
#include <sstream>
#include <string>
using namespace std;

void frases_paraules_consecutives_text(string &expressio,vector<string>& contingut ){
    for(int i = 0; i < contingut.size();++i){
        string paraules = contingut[i];
    	string op,ap;
    	int aux = 0;
    	string par;
    	
    	int cont = 0;
    	string express = expressio;
    	istringstream ss (express);
    	istringstream oo (paraules);
    	while (ss >> op){
    	    ++cont;
    	}
    	while (oo >> par){
    	    ++aux;
    	}
    	istringstream iss (paraules);
    	int count = 0;
    	while ((iss >> op) and (count < cont)){
    	    if ((op[op.size()-1] == ':') or (op[op.size()-1] == '.') or (op[op.size()-1] == ',') or (op[op.size()-1] == '?') or (op[op.size()-1] == '!') or (op[op.size()-1] == ';')){
                op.erase(op.size()-1,1); 
                
    	    }
            
    	    istringstream ass (expressio);
    	    ass >> ap;
    	    --aux;
    	    while ((op == ap) and (aux >= 0)){
                ++count;
                --aux;
    	        ass >> ap;
    	        iss >> op;

    	        if ((op[op.size()-1] == ':') or (op[op.size()-1] == '.') or (op[op.size()-1] == ',') or (op[op.size()-1] == '?') or (op[op.size()-1] == '!') or (op[op.size()-1] == ';')){
                    op.erase(op.size()-1,1);
    	        }
    	        if ((aux == 0) and (op == par)) ++count;
    	        if (count == cont) cout << i+1 << ' ' << paraules << endl;
    	    }
    	}
    }
}


int main(){
	vector<string> contingut;
	string n, op,expressio;
	getline(cin, expressio);
	cout << expressio << endl;
    cin >> n;
    bool next = 0;
    bool first = 1;
    int i = 0;
    while(n != "****"){
        if (first){
            contingut.push_back(n);
            first = 0;
        }
        else if (next){
            contingut.push_back(n);
            next = 0;
        }
        else if ((n[n.size()-1] == '.') or (n[n.size()-1] == '?') or (n[n.size()-1] == '!')){
            next = 1;
            contingut[i] += " " + n;
            ++i;
        }
        else {
            contingut[i] += " " + n;
        }
        cin >> n;
    }
    cout << "he acabado de leer" << endl;
    frases_paraules_consecutives_text(expressio, contingut);
    cout << "he echo la funcion" << endl;
}
