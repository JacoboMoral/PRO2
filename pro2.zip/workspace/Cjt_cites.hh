#ifndef Cjt_cites_hh
#define Cjt_cites_hh


/** @file Cjt_cites.hh
    @brief Especificació de la classe Cjt_cites
*/

#ifndef NO_DIAGRAM
#include <map>
#endif
#include "Cita.hh"
using namespace std;
/** @class Cjt_cites
    @brief Representa el conjunt de cites. 
    Es guardaran totes les cites. Cada cita té una referència única. Si s'esborra la cita la referència no tornarà a ser assignada a cap cita
*/

class Cjt_cites
{

private:
	/** @brief Conté cadascuna de les cites guardades en el sistema juntament amb la seva referència */
	map <string,Cita >mapcites;
	
	/** @brief Guarda el número màxim fins al moment per a cada inicial, per tal de fer sempre una referència nova que mai ha estat usada per cap cita */
	map<string,int> maxnum_inicials;


public:

    //constructora

   	/** @brief Creadora per defecte. S'executa automàticament en declarar un conjunt de cites
    
      	\pre <em>Cert</em>
    	\post El resultat és un conjunt de cites buit
  	*/
  	Cjt_cites();


    //modificadores
  
    /** @brief Afegeix una cita al conjunt
   
        \pre El paràmetre implícit no conté cap cita amb el mateix contingut i provinent del mateix text
        \post S'ha afegit la cita <cta> al paràmetre implícit juntament amb la seva referència
    */
    void afegir_cita(Cita &cta);
    
    /** @brief Elimina la cita representada per la seva referència
   
        \pre <em>Cert</em>
        \post S'esborra del paràmetre implícit la cita que tenia per referència <ref> si existeix la cita
    */
    void eliminar_cita(string &ref);
    

    //consultores d'escriptura
    
    /** @brief Mostra la informació d'una cita 
   
        \pre <em>Cert</em>
        \post Mostra l'autor, el títol, el número de la frase inicial i el de la frase final, a més del contingut de
        la frase o frases que componen la cita i la seva referència pel canal estàndard de sortida si existeix la cita
    */
    void informacio_cita(string &ref);
  
    /** @brief Mostra totes les cites d'un mateix autor
   
        \pre <em>Cert</em>
        \post Mostra totes les cites pel canal estàndard de sortida (referència, frases i títol) de l'autor <autor>
    */
    void cites_autor(string &autor);
      
    /** @brief Mostra totes les cites del conjunt de cites.
   
        \pre <em>Cert</em>
        \post Mostra pel canal estàndard de sortida totes les cites (referència, frases i títol) del paràmetre implícit
    */
    void mostrar_totes_cites();
     
       /** @brief Mostra la cita de l'ultim text triat.
   
        \pre <em>Cert</em>
        \post Mostra pel canal estàndard de sortida totes les cites del paràmetre implícit que siguin de l'autor <autor>
        y del text amb títol <titol>
    */
    void cites_text_triat(string &autor, string &titol,bool tipo);

    
    // destructora
  
    /** @brief Destructora per defecte.
   
        \pre <em>Cert</em>
        \post Esborra els objectes automàticament en sortir d'un àmbit de visibilitat
    */
    ~Cjt_cites();

};


#endif
