#ifndef Text_hh
#define Text_hh


/** @file Text.hh
    @brief Especificació de la classe Text
*/


#ifndef NO_DIAGRAM
#include <string>
#include <iostream>
#include <vector>
#include <sstream>
#include <map>
#include <algorithm>
#include <list>
#endif
using namespace std;

/** @class Text
    @brief Representa un text.
    Definim text com el conjunt de frases, sense autor ni títol.
 */

class Text
{

private:
	/** @brief Vector que guarda cadascuna de les frases del Text ordenades per número de frase, en el mateix ordre en què es llegeixen */
	vector<string> contingut;
    
public:

    //constructora
    
    /** @brief Creadora per defecte. S'executa automàticament en declarar un text
     
        \Pre <em>Cert</em>
        \Post El resultat és text buit, és a dir, sense cap frase
    */  
    Text();

    
    //modificadores
    
    /** @brief Substitueix totes les aparicions d'una paraula per una altra en el text
     
    	\pre <em>Cert</em>
        \post Substitueix en totes les frases del paràmetre implícit totes les aparicions de la paraula <original> per
        la paraula <nova>
    */
    int substituir_paraula(string &original, string &nova);
    
    
    //lectura i escriptura
    
    /** @brief Llegeix un text
     
        \pre Hi ha preparat al canal estàndard d'entrada un text que consta d'unes línies de contingut
        \post El paràmetre implicit ara conté aquestes linies de text
    */
    void llegir_contingut();
    
    
    /** @brief Mostra les frases entre la x i la y
    
    	\pre <em>Cert</em>
    	\post Mostra pel canal estàndard de sortida les frases entre la x-èsima i la y-èsima del paràmetre implícit precedides del seu número
    	de frase. Si x = y = -1, s'escriuran totes les frases automàticament
    */
	void escriure_contingut(int x, int y);
	
	/** @brief Mostra les frases que compleixen l'expressió
		\pre <em>Cert</em>
		\post Mostra pel canal estàndard de sortida les frases del paràmetre implícit que compleixin l'expressió <expressio>
	 */
    void frases_compleixen_expressio(string &expressio);
    
    /** @brief Mostra les frases del text en les que hi apareix una seqüència de paraules
   
    	\pre <em>Cert</em>
        \post Mostra pel canal estàndard de sortida les frases del paràmetre implícit en què apareixen totes les paraules <expressio>
        i en el mateix ordre, sense tenir en compte els signes de puntuació
    */
     void frases_paraules_consecutives_text(string &expressio);
    
    
    //consultores
  	
    /** @brief Consulta las frases del text
    
    	\pre <em>Cert</em>
    	\post El resultat és un vector que conté a cada posició una frase del paràmetre implícit
    */
    vector<string> consultar_frases() const;
    
    /** @brief Consulta si una frase compleix una expressio booleana de paraules
     	\pre <em>Cert</em>
     	\post El resultat és cert si la frase <frase> compleix l'expressió <expressio>, fals altrament
     */
    bool expressio_recursiva(string &expressio, string &frase);
   
    /** @brief Cerca una paraula en el text
     	\pre <em>Cert</em>
     	\post El resultat és cert si la paraula <paraula> es troba a la frase <frase>, fals altrament
     */
    bool cercar_paraula(string &frase, string &paraula);

    /** @brief Mostra el nombre de frases del text
   
    \pre <em>Cert</em>
    \post El resultat és el nombre de frases del paràmetre implícit
    */
    int nombre_frases() const;
  
    /** @brief Mostra el nombre de paraules del contingut de l'últim text triat.
   
    \pre <em>Cert</em>
    \post El resultat és el nombre de paraules del paràmetre implícit
    */
    int nombre_paraules() const;
    
    
    // destructora
    
    /** @brief Destructora per defecte.
   
        \pre <em>Cert</em>
        \post Esborra els objectes automàticament en sortir d'un àmbit de visibilitat
    */ 
  ~Text();

};


#endif