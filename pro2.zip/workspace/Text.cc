/** @file Text.cc
    @brief Codi de la classe Text
*/

#include "Text.hh"
using namespace std;


Text::Text(){
}


Text::~Text(){
}


int Text::substituir_paraula(string &original, string &nova) {
    int cont = 0;
    for(int i = 0; i < contingut.size(); ++i){
        int size = original.size();
        int pos = contingut[i].find(original);
        while(pos != -1){
            char c = contingut[i][pos + size];
            if (pos == 0){
                if ((c == ' ') or (c == '.') or (c == ',') or (c == '?') or (c == '!') or (c == ';') or (c == ':')){
                    contingut[i].replace(pos, original.size(), nova);
                    ++cont;
                }
            }
            else{
                char k = contingut[i][pos-1];
                if (((c == ' ') or (c == '.') or (c == ',') or (c == '?') or (c == '!') or (c == ';') or (c == ':')) and (k == ' ')){ 
                    contingut[i].replace(pos, original.size(), nova);
                    ++cont;
                }
            }
            pos = contingut[i].find(original, pos+1);
        }
    }
    return cont;
}


void Text::llegir_contingut(){
    string paraula;
    cin >> paraula;
    string frase = "";
	while (paraula != "****"){
		if ((paraula[paraula.size()-1] == '.') or (paraula[paraula.size()-1] == '?') or (paraula[paraula.size()-1] == '!')){
			frase += paraula;
			contingut.push_back(frase);
			frase = "";
		}
		else frase += paraula + " ";
		cin >> paraula;
	}
}


vector<string>Text::consultar_frases() const{
	return contingut;
}


int Text::nombre_frases() const{
     return contingut.size();
}


int Text::nombre_paraules() const{
	string op;
	int cont = 0;
	for (int i = 0; i < contingut.size(); ++i){
		istringstream iss (contingut[i]);
		while (iss >> op) ++cont;
	}
    return cont;
}


void Text::escriure_contingut(int x, int y){
    if ((x == -1) and (y == -1)){
        for (int i = 0; i < contingut.size(); ++i){
            cout << i+1 << " " << contingut[i] << endl;
        }
	}
    else {
		for (int i = x; i <= y; ++i){
            cout << i << " " << contingut[i-1] << endl;
		}
	}
}


bool Text::cercar_paraula(string &frase,string &paraula){
    string op;
    istringstream iss (frase);
    while (iss >> op){
        if(op[op.size()-1] == ',' or op[op.size()-1] == '.' or op[op.size()-1] == '?' or op[op.size()-1] == ';' or op[op.size()-1] == ':' or op[op.size()-1] == '!'){
				op.erase(op.size()-1,1);
			}
		if (op == paraula) return 1;
    }
    return 0;
}


void Text::frases_compleixen_expressio(string &expressio){
    for (int i = 0; i < contingut.size(); ++i){
        if (expressio_recursiva(expressio,contingut[i]) == 1) cout << i+1 << ' ' << contingut[i] << endl;
    }
}


bool Text::expressio_recursiva(string &expressio, string &frase){
    if (expressio[0] == '('){
    	int cierra = 0;
        int abre = 0;
        char simbol_or_and;
        bool simbol_or_and_trobat = 0;
        int cont = 1;
        while (simbol_or_and_trobat == 0 and (expressio.size()-1 > cont)){
            if (expressio[cont] == ')') ++cierra;
            else if (expressio[cont] == '(') ++abre;
            if (abre == cierra){
                if (expressio[cont] == '&'){
                    simbol_or_and = expressio[cont];
                    simbol_or_and_trobat = 1;

                }
                else if (expressio[cont] == '|'){
                    simbol_or_and = expressio[cont];
                    simbol_or_and_trobat = 1;
                }
            }
            if (simbol_or_and_trobat == 0) ++cont;
        }
        
        if (simbol_or_and_trobat == 1){
            string esquerra = expressio;
            esquerra.erase(0,1);
            esquerra.erase(cont-2);
            string dreta = expressio;
            dreta.erase(0,cont+2);
            dreta.erase(dreta.size()-1);
            if(simbol_or_and == '&'){
                if ((expressio_recursiva(esquerra,frase) == 1) and (expressio_recursiva(dreta,frase) == 1)) return 1;
                else return 0;
            }
            else{
                if ((expressio_recursiva(esquerra,frase) == 1) or (expressio_recursiva(dreta,frase) == 1)) return 1;
                else return 0;
            }
        }
    }
    else {
        string express = expressio;
        express.erase(0,1);
        express.erase(express.size()-1);
        istringstream iss(express);
        string paraula;
        while (iss >> paraula){
           	if (cercar_paraula(frase,paraula) == 0) return 0;
        }
    }
    return 1;
}


void Text::frases_paraules_consecutives_text(string &expressio){
for(int i = 0; i < contingut.size(); ++i){
    string paraules = contingut[i];
	string op,ap;
	int aux = 0;
	string par;
    int cont = 0;
    string express = expressio;
    istringstream ss (express);
    istringstream oo (paraules);
    while (ss >> op){
	    ++cont;
    }
    while (oo >> par){
	    ++aux;
	}
	istringstream iss (paraules);
	int count;
    while ((iss >> op) and (count < cont)){
        count = 0;
        if ((op[op.size()-1] == ':') or (op[op.size()-1] == '.') or (op[op.size()-1] == ',') or (op[op.size()-1] == '?') or (op[op.size()-1] == '!') or (op[op.size()-1] == ';')){
            op.erase(op.size()-1,1); 
	    }
        istringstream ass (expressio);
        ass >> ap;
    	--aux;
    	 while ((op == ap) and (aux >= 0) and (count != cont)){
            ++count;
            --aux;
    	    ass >> ap;
    	    iss >> op;
    	    if ((op[op.size()-1] == ':') or (op[op.size()-1] == '.') or (op[op.size()-1] == ',') or (op[op.size()-1] == '?') or (op[op.size()-1] == '!') or (op[op.size()-1] == ';')){
                op.erase(op.size()-1,1);
    	    }
    	    if ((aux == 0) and (op == par)){
    	    	 ++count;
    	    }
        }
    }
    if (cont == count) cout << i+1 << ' ' << paraules << endl;
    count = 0;
	}
}