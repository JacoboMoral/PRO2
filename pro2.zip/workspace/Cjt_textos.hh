#ifndef Cjt_textos_hh
#define Cjt_textos_hh

/** @file Cjt_textos.hh
    @brief Especificació de la classe Cjt_textos
*/

#ifndef NO_DIAGRAM
#include <sstream>
#include <map>
#endif
#include "Text.hh"
using namespace std;
/** @class Cjt_textos
    @brief Representa un conjunt de textos.
    Es guardaran tots els textos afegits juntament amb el seu títol i autor
 */

class Cjt_textos
{
  
private:
	/** @brief Boolea que ens diu si hi ha un text triat */
	bool existeix_text_triat; 
	
	/** @brief Conjunt de textos 
	El conjunt de textos esta ordenat alfabeticament per l'autor, la clau es l'autor ,i dins
	del primer map hi ha el titol com a clau del segon map i el contingut del text*/
	map <string,map<string,Text> > conjunt;
	
	/** @brief Iterador que apunta al autor triat , si existeix_text_triat es fals no es rellevant */
	map<string,map<string,Text> >::iterator it_triat_autor;
	
	/** @brief Iterador que apunta al text triat  si existeix_text_triat es fals no es rellevant */
	map<string,Text>::iterator it_triat_titol_i_contingut;
	
	/** @brief Autor triat de l'ultim text triat */
	string autor_triat;
	
	/** @brief Titol triat de l'ultim text triat  */
	string titol_triat;
	
	/** @brief Conjunt de paraules sense repetir amb la seva freqüència d'aparicions
	Està ordenada per freqüència decreixentment, desprès per llargària de cada paraula creixentment i
	finalment alfabèticament creixentment */
	list <pair<string,int> >taulafreq;
	
	/** @brief Busca una palabra a dintre d'un string de paraules separades d'espais i/o signes de puntuació
     
        \pre <em>Cert</em
        \post El resultat és 1 si la paraula es troba al string, 0 altrament
    */
	bool search(string palabra, string palabras);
	
	/** @brief Busca una palabra a dintre d'un text
     
        \pre <em>Cert</em
        \post El resultat és 1 si la paraula es troba al Text, 0 altrament
    */
	bool search_txt(string palabra, const Text& txt);
	
	/** @brief Llegeix el títol d'un text
     
        \pre Hi ha al canal estàndard de entrada un títol entre cometes
        \post El resultat és un string títol sense cometes amb el títol d'un text
    */
	string llegir_titol(string titol);
	
	/** @brief Llegeix l'autor d'un text
     
        \pre Hi ha al canal estàndard de entrada un autor entre cometes
        \post El resultat és un string autor sense cometes amb l'autor d'un text
    */
	string llegir_autor();
	
	/** @brief Ordena la taula de freqüències 
     
        \pre <em>Cert</em>
        \post Conté la informació de com s'ha d'ordenar la taula de frequències
    */
    static bool ordenar_taula_freq(const pair<string,int> &i, const pair<string,int> &j);

    /** @brief Llegeix un text
     
        \pre Hi ha al canal estàndard un seguit de frases terminades en el string "****"
        \post El resultat es un text de la classe Text
    */
    Text llegir_textos();
    
    /** @brief Crea i ordena la taula de freqüències
     
        \pre <em>Cert</em>
        \post La llista taulafreq conté totes les paraules del text i la seva freqüència
    */
    void fer_taula_freq();

  	/** @brief Substitueix una paraula per un altra a la taula de freqüències
     
        \pre <em>Cert</em> 
        \post La taula de freqüències ja no conté la paraula que s'ha substituït, i la nova, si ja estava, s'incrementa la seva freqüència.
        Si no estava, ara té la freqüència de la substituïda
    */
	void substituir_paraula_taula_freq(string &original, string &nova, int aparicions);
	
	/** @brief Es reordena la taula de freqüències
     
        \pre Hi ha al canal estàndard de entrada un títol entre cometes
        \post El resultat es un string títol sense cometes amb el títol d'un text
    */
	
public:
    
    //Constructores

    /** @brief Creadora per defecte. S'executa automaticament en declarar un conjunt de textos.
     
        \pre <em>cert</em>
        \post El resultat és un conjunt de textos buit 
    */  
    Cjt_textos();
    
    
  
    //Modificadores
    
    /** @brief Substitueix una paraula per un altra en el text triat
     
        \pre <em>Cert</em>
        \post Substitueix totes les aparicions d'una paraula, si està, al text triat per una altra
    */
    void substitueix_paraula_triat(string &original, string &nova);
	
    /** @brief Tria un text
     
        \pre <em>Cert</em>
        \post it_triat_titol_i_contingut s'actualitza apuntant al text triat. Si no s'ha trobat cap text que tingui totes les paraules o n'hi ha més d'un,
        s'haurà de mostrar error per pantalla
    */
    void triar_text(string paraules);


    //Consultores 
  	
  	/** @brief Consulta l'autor del text triat
   
        \pre S'ha triat un text prèviament
        \post El resultat es un string amb l'autor del text triat
    */ 
  	string consultar_autor_triat();
  	
  	/** @brief Consulta el títol del text triat
   
        \pre S'ha triat un text prèviament
        \post El resultat es un string amb el títol del text triat
    */ 
  	string consultar_titol_triat();
  	
  	/** @brief Consulta les frases del text triat entre la x i la y
   
        \pre S'ha triat un text prèviament
        \post El resultat és un vector que conté les frases des de la x fins la y del text triat. Si x = y = -1, retorna totes.
    */ 
  	vector<string> consultar_frases_text_triat(int x, int y);
  	
  	/** @brief Consulta si n'hi ha un text triat al sistema
   
        \pre <em>Cert</em>
        \post El resultat és 1 si n'hi ha un text triat, 0 altrament
    */ 
  	bool hi_ha_text_triat();
  	
    /** @brief Elimina el text triat
   
        \pre S'ha triat un text prèviament
        \post El conjunt de textos ja no conté el text que estava triat, ni el seu títol, i si era l'únic de l'autor, tampoc hi haurà aquest. Ja no hi ha text triat
    */
    void eliminar_text();
  
  
    //Entrada i sortida
    
    /** @brief Mostra els textos d'un determinat autor
     
        \pre <em>Cert</em>
        \post Mostra una llista de títols corresponents al autor <autor>
    */
    void mostrar_textos_autor(string &autor);
    
    /** @brief Mostra tots els autors afegits, el nombre de textos de cadascun, el nombre de paraules i de frases del text.
     
        \pre <em>cert</em>
        \post Mostra una llista ordenada alfabèticament dels autors dels textos del paràmetre implícit,
        a més de del nombre de textos de cadascun, i del nombre de paraules i de frases del contingut dels
        textos
    */
    void tots_autors();
     
    /** @brief Mostra la taula de freqüències de les paraules del text triat
     
        \pre S'ha triat un text prèviament 
        \post Mostra pel canal estàndard de sortida una llista de cada paraula amb la seva freqüència en el text triat. Estan ordenades per freqüència decreixenment, després 
        creixentment per llargària i finalment creixentment alfabèticament
    */ 
  	void mostrar_taula_freq();
  	
  	/** @brief Mostra totes les frases del text triat
     
        \pre S'ha triat un text prèviament
        \post Mostra pel canal estàndard de sortida totes les frases, enumerades, del text triat
    */
    void mostrar_tot_contingut();

    /** @brief Mostra tots els textos afegits
     
        \pre <em>Cert</em> 
        \post Mostra pel canal estàndard de sortida una llista ordenada dels autors i títols de tots els textos del paràmetre implícit, ordenats
        primer per autor i després per títol
    */
    void tots_textos();

    /** @brief Mostra informació de l'últim text triat
   
        \pre Ha d'haver-se afegit un text anteriorment
        \post Mostra pel canal estàndard de sortida l'autor, títol, nombre de frases, nombre de paraules i cites associades del text triat
    */
   void info();

    /** @brief Mostra l'autor de l'últim text triat
   
        \pre S'ha triat un text prèviament
        \post Escriu pel canal estàndard de sortida l'autor del text triat
    */
    void mostrar_autor();
  
    /** @brief Mostra les frases x-èssima a y-èssima
   
        \pre S'ha triat un text prèviament
        \post Escriu pel canal estàndard de sortida les frases del text triat entre ics i i_grega. Aquestos son strings que representen nombres naturals
    */
    void mostrar_contingut_x_y(string &ics, string &i_grega);
    
	/** @brief Mostra les frases que compleixen una expressió booleana
   
        \pre S'ha triat un text prèviament
        \post Escriu pel canal estàndard de sortida cadascuna de les frases del text triat que compleixen una expressió booleana
    */ 
  	void frases_expressio_conjunt(string &line);
  	
  	
  	/** @brief Mostra les frases que contenen unes paraules de forma consecutiva
   
        \pre S'ha triat un text prèviament
        \post Escriu pel canal estàndard de sortida cadascuna de les frases del text triat que contenen les paraules de forma consecutiva
    */
  	void frases_paraules_consecutives_conjunt(string &paraules);
  
   	/** @brief Mostra el nombre de paraules del text triat
  
        \pre S'ha triat un text prèviament
        \post Mostra pel canal estàndard de sortida el nombre de frases del text triat
    */ 
   	void mostra_nombre_paraules_triat();
   	
   	/** @brief Mostra el nombre de frases del text triat
   
        \pre S'ha triat un text prèviament
        \post Mostra pel canal estàndard de sortida el nombre de frases del text triat
    */ 
   	void mostra_nombre_frases_triat();
   
    /** @brief Afegeix un text
     * 
        \pre El paràmetre implícit no conté cap text amb el mateix autor i títol
        \post S'ha afegit un nou text amb el seu títol i autor al paràmetre implícit
    */
    void afegir_text(string &linia);
  
    
    //Destructora
  
    /** @brief Destructora per defecte
   
        \pre <em>Cert</em>
        \post Esborra els objectes automàticament en sortir d'un àmbit de visibilitat
    */ 
    ~Cjt_textos(); 

};

#endif