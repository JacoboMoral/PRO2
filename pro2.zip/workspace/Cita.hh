#ifndef Cita_hh
#define Cita_hh


/** @file Cita.hh
    @brief Especificació de la classe Cita
*/


#ifndef NO_DIAGRAM
#include <string>
#include <utility>
#include <vector>
#include "Cjt_textos.hh"
#include <iostream>
#include <sstream>
#endif
using namespace std;

/** @class Cita
    @brief Representa una cita, que és un conjunt de frases extretes d'un text

 */

class Cita
{
private:
	/** @brief Numero de frase inicial*/
	int frase_ini;
	
	/** @brief Iniciales del autor */
	string inicials_cita;
	
	/** @brief autor de la cita */
	string autor_cita;
	
	/** @brief titulo de la cita */
	string titol_cita;
	
	/** @brief Las citas del texto.
	Ordenadas por el numero de frase*/
	vector<string> contingut_cita;
	

public:

    //constructores
    
    /** @brief Creadora per defecte. S'executa automàticament en declarar una cita
     
        \pre <em>Cert</em>
        \post El resultat és una cita buida
    */  
    Cita();
    
    /** @brief Creadora inicialitzada
     
        \pre <em>Cert</em>
        \post El resultat és una cita amb un autor <autor, un títol <titol> i un conjunt de frases <con>
    */
    Cita(string autor,string titol,int x,vector<string> con);


    //Entrada i sortida
    
    /** @brief Creadora inicialitzada
     
        \pre <em>Cert</em>
        \post Escriu pel canal estàndard d'escriptura cadascuna de les frases de la cita precedides pel seu número de frase en el 
        text original d'on s'han extret
    */
    void escriure_contingut_cita();
    
    
    //Consultores

    /** @brief Consulta l'autor de la cita
     
        \pre El paràmetre implícit té autor
        \post El resultat és l'autor del paràmetre implícit
    */
    string consultar_autor();
    
    /** @brief Consulta inicials del autor
      
        \pre El paràmetre implícit té inicials
    	\post El resultat són les inicials del paràmetre implícit
    */
    string consultar_inicials();
    
    /** @brief Consulta les frases de la cita
      
        \pre <em>Cert</em>
    	\post El resultat és el conjunt de frases del paràmetre implícit
    */
    vector<string> consultar_contingut_cita();

    /** @brief Consulta el nombre de frases de la cita
      
        \pre <em>Cert</em>
    	\post El resultat és el nombre de frases del paràmetre implícit
    */
	int consultar_nombre_frases_cita();
    
    /** @brief Consulta el títol de la cita
      
        \pre El paràmetre implícit té títol
        \post El resultat és el títol del paràmetre implícit
    */
    string consultar_titol();

    /** @brief Consultar el número de frase inicial
      
        \pre S'ha inicialitzar una cita i aquesta té al menys una frase
        \post El resultat és el número de frase de la primera frase de la cita en el text original
        d'on s'ha extret
    */
    int consultar_frase_ini();
	
	
	//modificadores
	
	/** @brief Fa les inicials del autor
      
        \pre El paràmetre implícit té autor
        \post inicials_cita ara és un string format per cadascuna de les inicials de l'autor del
        paràmetre implícit
    */
	void fer_inicials(); 
	
    
    // destructora
    
    /** @brief Destructora per defecte.
  
        \pre <em>Cert</em>
        \post Esborra els objectes automàticament en sortir d'un àmbit de visibilitat
    */ 
    ~Cita();
    
};

#endif