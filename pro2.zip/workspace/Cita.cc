/** @file Cita.cc
    @brief Codi de la classe Cita
*/

#include "Cita.hh"
using namespace std;


Cita::Cita(){
}


Cita::~Cita(){
}


Cita::Cita(string autor,string titol,int x,vector<string> con){
    titol_cita = titol;
  	frase_ini = x;
    contingut_cita = con;
  	autor_cita = autor;
  	fer_inicials();
}


string Cita::consultar_autor(){
    return autor_cita;
}


string Cita::consultar_inicials(){
    return inicials_cita;
}


string Cita::consultar_titol(){
    return titol_cita;
}


vector<string> Cita::consultar_contingut_cita(){
    return contingut_cita;
}
void Cita::escriure_contingut_cita(){
    for (int i = 0; i < contingut_cita.size(); ++i){
        cout << i+frase_ini+1 << ' ' << contingut_cita[i] << endl;
    }
}



int Cita::consultar_frase_ini(){
    return frase_ini;
}


void Cita::fer_inicials(){
    istringstream iss (autor_cita);
    string op;
	 while (iss >> op){
	    inicials_cita += op[0];
    }
}


int Cita::consultar_nombre_frases_cita(){
   	return contingut_cita.size();
}