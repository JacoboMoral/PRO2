/**
 * @mainpage Pràctica de Pro2:  Gestió de llibres i cites.
 
En aquest programa es gestiona un conjunt de textos amb autor i títol, llibres, i també cites tretes d'aquests llibres. S'utilitzen les classes <em>Cjt_textos</em>, 
<em>Text</em>, <em>Cjt_cites</em> y <em>Cita</em>.

*/

/** @file program.cc
    @brief Programa principal de la pràctica de Pro2.
*/

#ifndef NO_DIAGRAM
#include <sstream>
#include <iostream>
#endif
#include "Cjt_textos.hh"     
#include "Text.hh"              
#include "Cjt_cites.hh"
#include "Cita.hh"
using namespace std;

int main(){
    string linia, op, seg, sublinia;
    Cjt_textos llibre;
    Cjt_cites cites;
    do{
    	getline(cin,linia);
    }while (linia.empty());
    while (linia != "sortir"){
        istringstream iss(linia);
        iss >> op;
        cout << linia << endl;
        if (op == "afegir"){
            iss >> seg;
            if (seg == "text"){
                llibre.afegir_text(linia);
            }
            else if (seg == "cita"){
                ws(iss);
                if (llibre.hi_ha_text_triat()){
                	iss >> seg;
					int x = atoi(seg.c_str())-1;
                	iss >> seg;
                	int y = atoi(seg.c_str())-1;
                	if ((x+1) > 0 and (y+1) >= (x+1)){
                		vector<string> v = llibre.consultar_frases_text_triat(x,y);
                		if (v.size() > 0){
                			Cita cta(llibre.consultar_autor_triat(),llibre.consultar_titol_triat(),x,v);
                			cites.afegir_cita(cta);
                		}
                		else cout << "error" << endl;
                	}
                	else cout << "error" << endl;
                }
                else cout << "error" << endl;
            }
        }
        else if(op == "triar"){
            llibre.triar_text(linia);
        }
        else if(op == "eliminar"){
            iss >> seg;
            if(seg == "text"){
            	if (llibre.hi_ha_text_triat()){
          			llibre.eliminar_text();
            	}
            	else cout << "error" << endl;
            }
            else if(seg == "cita"){
                iss >> seg;
            	cites.eliminar_cita(seg);
            }
        }
        else if(op == "substitueix"){
            iss >> op;
            iss >> seg;
            iss >> seg;
            if (llibre.hi_ha_text_triat()){
            	llibre.substitueix_paraula_triat(op,seg);
            }
            else cout << "error" << endl;
        }
        else if(op == "textos"){
            llibre.mostrar_textos_autor(linia);
        }
        else if(op == "tots"){
            iss >> seg;
            if(seg == "autors"){
                llibre.tots_autors();
                    
            }
            else if (seg == "textos"){
                llibre.tots_textos();
            }
        }
        else if(op == "info"){
        	
            iss >> seg;
            if (seg == "?"){
            	if (llibre.hi_ha_text_triat()){
                	llibre.info();
                	string autor = llibre.consultar_autor_triat();
                	string titol = llibre.consultar_titol_triat();
                	cites.cites_text_triat(autor,titol,0);
            	}
                else cout << "error" << endl;
            }
            else if (seg == "cita"){
            	iss >> seg;
            	cites.informacio_cita(seg);
            }
        }
        else if(op == "autor"){
        	if (llibre.hi_ha_text_triat()){
        		llibre.mostrar_autor();
        	}
        	else cout << "error" << endl;
        }
        else if(op == "contingut"){
        	if (llibre.hi_ha_text_triat()){
            	llibre.mostrar_tot_contingut();
        	}
        	else cout << "error" << endl;
        }
        else if(op == "frases"){
        	if (llibre.hi_ha_text_triat()){
            	string x;
            	iss >> x;
            	if ((x[0] == '(') or (x[0] == '{')){
					llibre.frases_expressio_conjunt(linia);	
	    		}
            	else if (x[0] == '"'){
            		llibre.frases_paraules_consecutives_conjunt(linia);
        		}
        		else{
            		string y;
            		iss >> y;
            		llibre.mostrar_contingut_x_y(x,y);
            	}
        	}
        	else cout << "error" << endl;
        }
        else if(op == "nombre"){
            iss >> seg;
            iss >> seg;
            if (seg == "frases"){
   				if (llibre.hi_ha_text_triat()){
            		llibre.mostra_nombre_frases_triat();
   				}
   				else cout << "error" << endl;
            }
            else if(seg == "paraules"){
            	if (llibre.hi_ha_text_triat()){
            		llibre.mostra_nombre_paraules_triat();
            	}
            	else cout << "error" << endl;
            }
        }
        else if(op == "taula"){
        	if (llibre.hi_ha_text_triat()){
        		llibre.mostrar_taula_freq();
        	}
        	else cout << "error" << endl;
        }
        else if(op == "cites"){
            iss >> seg;
            if (seg == "autor"){
            	cites.cites_autor(linia);
            }
            else if (seg == "?"){
            	if (llibre.hi_ha_text_triat()){
                	string autor = llibre.consultar_autor_triat();
                	string titol = llibre.consultar_titol_triat();
                	cites.cites_text_triat(autor,titol,1);
            	}
            	else cout << "error" << endl;
            }
        }
        else if(op == "totes"){
            cites.mostrar_totes_cites();
        }    
        do{
    	    getline(cin,linia);
    	}while (linia.empty());
    	cout << endl;
    }
}
